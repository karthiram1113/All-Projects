import { Component,OnInit,
  ViewChild,
  AfterViewInit,
  HostListener, } from '@angular/core';
  import { NgbPopoverConfig } from '@ng-bootstrap/ng-bootstrap';
  import { LanguageService } from '../services/language.service';
  import { TranslateService } from '@ngx-translate/core';
  import { Router, ActivatedRoute, ParamMap } from '@angular/router';
  import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { ApiServiceService } from '../services/api-service.service';
  // import { ReCaptchaService } from 'angular-recaptcha3';
  import Swal from 'sweetalert2';
  import { DatePipe } from '@angular/common';
  // import { Timepipe } from './TimeFormatPipe';
  import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
  // import { error } from 'console';

@Component({
  selector: 'app-appointment-new',
  templateUrl: './appointment-new.component.html',
  styleUrl: './appointment-new.component.scss',
  providers: [DatePipe],
})
export class AppointmentNewComponent implements  OnInit {

  options = [
    { label: 'confirmatory', value: 'confirmatory', checked: false },
    { label: 'Speciality', value: 'Speciality', checked: false },
    
  ];
  department: any;
  responseData: any;
  datas: any;

  // dropdown

  // Drop down api

// onCheckboxChange(event: any, option: any) {
//   option.checked = event.target.checked;
//  console.log(option);

 
// }

updateSelectedOptions() {
  this.selectedOptions = this.options
    .filter(option => option.checked)
    .map(option => option.label);
}

toggleDropdown() {
  this.isDropdownOpen = !this.isDropdownOpen;  
}

closeDropdown() {
  this.isDropdownOpen = false;
  "rrrrrrrrrr"
}

  data: any[] = [];
  selectedCenterCodes: Set<string> = new Set<string>();
  selectedCenterCode: string = 'CH'; // Initial center code
  dateResponse: any[] = [];
  dropdownVisible: boolean = false;
  storedResponse: any;
  invalid: any;
  cdr: any;
  select: any;
  startTime: any;
  endTime: any;
  time: any;
  value: any;
  one: any[] | undefined;
  sss: any;
  date: any;
  uniqueData: any[] = [];
  selectedDate: string | null = null;
  selectedTime: string | null = null;
  uniqueDates: any;
  isDropdownOpen = false;
  selectedOptions: string[] = [];
  // selectedTime: string | null = null;

  ngOnInit() {
    const storedData = localStorage.getItem('data');
    if (storedData) {
      this.data = JSON.parse(storedData);
      this.removeDuplicates();
    }
    this.loadDataFromLocalStorage();
    
  }

  removeDuplicates() {
    const seen = new Set();
    this.uniqueData = this.data.filter((item: { center_code: string }) => {
      const duplicate = seen.has(item.center_code);
      seen.add(item.center_code);
      return !duplicate;
    });
  }




  onCheckboxChange(event: any, option: any) {
    option.checked = event.target.checked;
    const centerCode = event.target.value;
    // Update selectedOptions based on checkbox state
    if (option.checked) {
        this.selectedOptions.push(option.label);
    } else {
        this.selectedOptions = this.selectedOptions.filter(
            (label) => label !== option.label
        );
    }



    console.log('Selected Options:', this.selectedOptions);

    // Collect departments based on selected options
    const departments = new Set<string>();

    // Iterate through selected options and data
    this.selectedOptions.forEach(selectedOption => {
        console.log(`Processing option: ${selectedOption}`);
        this.data.forEach(item => {
            console.log('Processing item:', item);

            // Process based on selected option
            if (selectedOption === 'confirmatory') {
                if (item.confirmatoryData?.department) {
                    departments.add(item.confirmatoryData.department);
                } else {
                    console.log('No confirmatory department in item:', item);
                }
            } else if (selectedOption === 'Speciality') {
                if (item.specialityData?.department) {
                    departments.add(item.specialityData.department);
                } else {
                    console.log('No specialty department in item:', item);
                }
            } else if (selectedOption === 'X-ray') {
                if (item.xrayData?.department) {
                    departments.add(item.xrayData.department);
                } else {
                    console.log('No x-ray department in item:', item);
                }
            } else {
                console.log('Unknown selected option:', selectedOption);
            }
        });
    });

    // Join departments into a comma-separated string
    const departmentList = Array.from(departments).join(',');
    console.log('Final department list:', departmentList);
    const uniqueCenterCodes = Array.from(new Set(this.data.map(item => item.center_code)));
    // Prepare API parameters
    const params = {
        center: uniqueCenterCodes,
        department: departmentList
    };

    console.log('Params for API:', params);

    // Fetch data based on the collected params
    this.fetchData(params);
}

fetchData(params: any) {
  this.apiservice.dropdownapi(params, params.center).subscribe(
      (response: any) => {
          if (response && response.data) {
              
              const departmentCodes = params.department.split(',');

             
              const filteredData = response.data.filter((item: any) => {
                
                  return item.depart_detail.some((detail: any) =>
                      departmentCodes.includes(detail.code)
                  );
              });

              
              const uniqueDates = this.getUniqueDates(filteredData);

              this.storedResponse = uniqueDates.map((item: any) => {
                  const dateObj = new Date(item.date);
                  return {
                      month: dateObj.toLocaleString('default', { month: 'short' }),
                      date: dateObj.getDate(),
                      day: dateObj.toLocaleString('default', { weekday: 'short' }),
                      fullDate: item.date
                  };
              });

              // Filter out duplicate fullDate values
              const seen = new Set();
              this.uniqueDates = this.storedResponse.filter((item: { fullDate: string }) => {
                  const duplicate = seen.has(item.fullDate);
                  seen.add(item.fullDate);
                  return !duplicate;
              });

              console.log('Transformed Response:', this.storedResponse);
          } else {
              console.error('Invalid API response:', response);
          }
      },
      (error) => {
          console.error('Error fetching data:', error);
      }
  );
}
private getUniqueDates(data: any[]): any[] {
  const uniqueDates = [];
  const map = new Map();
  for (const item of data) {
      if (!map.has(item.date)) {
          map.set(item.date, true);
          uniqueDates.push(item);
      }
  }
  return uniqueDates;
}





  // toggleDropdown() {
  //   this.dropdownVisible = !this.dropdownVisible;
  // }

// 




// Date Click To Time Open Api

 
  datefunction(params:any) {

        
    this.apiservice.dropdownapi(params, params.center).subscribe(
      (response: any) => {
        // Check if response and response.data are defined
        if (response && response.data) {
          
          this.dateResponse = this.getUniqueTimeSlots(response.data.flatMap((item: any) => item.slottime));
          console.log('API Response:', this.dateResponse); 
        } else {
          console.error('Invalid API response:', response); 
        }
      },
      (error: any) => {
        console.error('Error fetching data:', error); 
      }
    );
  }

  // Helper function to get unique time slots
  getUniqueTimeSlots(slots: any[]): any[] {
    const uniqueSlots = [];
    const map = new Map();
    for (const slot of slots) {
      const key = slot.start_time + '-' + slot.end_time;
      if (!map.has(key)) {
        map.set(key, true); 
        uniqueSlots.push(slot);
      }
    }
    return uniqueSlots;
  }


//  Book Appointment Button Api

bookAppointment() {
  const item = this.data[0];

  const data = {
    "applicant_id": item.applicant_id,
    "patient_name": item.patient_name,
    "visa_number": item.visa_number,
   
    "department":item.confirmatoryData?item.confirmatoryData.department:item.specialityData.department,

    "service": item.confirmatoryData?item.confirmatoryData.service: item.specialityData.service,

    "service_code":item.confirmatoryData?item.confirmatoryData.service_code:item.specialityData.service_code ,
    "description": 3,
      // "booking_status": item.confirmatoryData?.booking_status, 
    "booking_status": 1, 
    "date_booked": this.selectedDate,
    "booked_time": this.time,
    "booking_from": "3"
  };

  this.apiservice.bookappointmentapi(data).subscribe(
    (res) => {
      console.log('API Response:', res); 

      if (res && res.status === 1) {
        this.applicantdata = res.result;
        this.apiservice.token = res.token;
        console.log(item.confirmatoryData?.service_code);
        
        this.router.navigate(['/appointmentview']).then(success => {
          if (success) {
            console.log('Navigation successful');
          } else {
            console.error('Navigation failed');
          }
        });
      } else {
        // Handle other status codes or unexpected responses
        console.error('Unexpected API response:', res);
        alert('An unexpected response occurred.');
      }
    },
    (error) => {
      console.error('API error: ', error);
      alert('An error occurred while processing your request.');
    }
  );
}






  @ViewChild('availableslot')
  availableslot!: NgbModalConfig;
  @ViewChild('unavailableslot')
  unavailableslot!: NgbModalConfig;
  @ViewChild('OTPModel')
  OTPModel!: NgbModalConfig;
  @ViewChild('slotbooked')
  slotbooked!: NgbModalConfig;
  @ViewChild('slotsempty')
  slotsempty!: NgbModalConfig;
  windowWidth: any = window.innerWidth < 600 ? window.innerWidth : '1100';
  lang: any;
  stricky: any = false;
  isShow = true;
  model2: any;
  visavalidation: boolean = true;
  siteKey = '6LcmxJ4pAAAAAGcfYMzHJWbd-pxAzCZdiUVer_VB';
  loginform!: FormGroup;
  booking: boolean = true;
  history: boolean = false;
  applicantdata: any = {};
  userdetail: any = {};
  applicantdetailpage: boolean = false;
  appointmenthistorydata: any = [];
  slotgroup: any = [];
  showslotgroup: any[] = [];
  startslotindex: any;
  endslotindex: any;
  selectedslot: any;
  Slottime: any[] = [];
  selectedslottimeitem: any;
  Bookedslots: any;
  referralDetails: any;
  bsConfig?: Partial<BsDatepickerConfig>;
  fromhistory: boolean = false;
  historyitem: any;
  OTPvalue: any;
  checkotp: boolean = true;
  selecteddayindex: any;
  country: any;

  constructor(
    public route: ActivatedRoute,
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    public router: Router,
    config: NgbPopoverConfig,
    private translate: TranslateService,
    private language: LanguageService,
    public datepipe: DatePipe,
    private apiservice: ApiServiceService
  ) {
    config.placement = 'right';
    config.triggers = 'hover';
    this.translate.use('en');
    this.language.languageChange.subscribe((props) => {
      this.lang = props;
    });
    this.bsConfig = Object.assign({}, { containerClass: 'theme-dark-blue' });
    this.country = localStorage.getItem('country');
    // console.log(JSON.parse(this.data));
  }
 
  toggleDisplay() {
    this.isShow = !this.isShow;
  }



  selectTime(startTime: any, endTime: any) {
    // Your logic here using startTime and endTime
    this.selectedTime = `${startTime} - ${endTime}`;
    console.log({ startTime }, { endTime });
    this.startTime = startTime;
    this.endTime = endTime;
    this.time = startTime + " " + endTime

    console.log(this.time);
  }

  isSelectedTime(startTime: string, endTime: string): boolean {
    return this.selectedTime === `${startTime} - ${endTime}`; 
  }

  clickDate(date: string) {
    this.date = this.formatDate(date);
    console.log('Selected date:', this.date);
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); 
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  }

  // Date Click To Highlight
  handleDateClick(fullDate: string) {
    if (this.selectedDate === fullDate) {
      this.selectedDate = ''; 
    } else {
      this.selectedDate = fullDate; 
    }

    console.log('Selected date:', this.selectedDate);

    // Call datefunction only if a date is selected
    if (this.selectedDate) {
      this.datefunction('yourCenterCode'); // Pass the appropriate centerCode
    }
  }

  handlemulticlick(clickedDate: string) {
    this.selectedDate = clickedDate === this.selectedDate ? null : clickedDate;
  }

  // Appointment Api Loading
 
 loadDataFromLocalStorage(): void {
   const storedDatas = localStorage.getItem('viewData');
   if (storedDatas) {
     this.datas = JSON.parse(storedDatas);
   }
 }
 onButtonClick(): void {
  const visa_number = sessionStorage.getItem('visa_number');
  if (!visa_number) {
    alert('No visa number found in session storage.');
    return;
  }
  const paramss = { visa_number: visa_number }; 
  // const params = { visa_number: '987856745654' }; 
  console.log(paramss);

  this.apiservice.appointmentHistory(paramss).subscribe({
    next: (response) => {
      
      this.responseData = response;
      console.log('API response:', response);
    
      localStorage.setItem('viewData',JSON.stringify(response.data));
      this.loadDataFromLocalStorage();
      this.router.navigate(['/appointmentview']);
      // window.location.reload();
    },
    error: (err) => {
      console.error('API call error:', err);
      
    }
  });
}
  
}
